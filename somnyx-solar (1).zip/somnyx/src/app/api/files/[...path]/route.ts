import path from "node:path";
import { MIME, readLocal } from "@/lib/storage";

export const runtime = "nodejs";

/** Serves locally stored PUBLIC files (development / self-hosting). Private files are never served here. */
export async function GET(_req: Request, { params }: { params: Promise<{ path: string[] }> }) {
  const parts = (await params).path;
  if (parts[0] !== "public") return new Response("Not found", { status: 404 });
  const key = parts.join("/");
  const buf = await readLocal(key);
  if (!buf) return new Response("Not found", { status: 404 });
  const ext = path.extname(key).toLowerCase();
  return new Response(new Uint8Array(buf), {
    headers: { "Content-Type": MIME[ext] ?? "application/octet-stream", "Cache-Control": "public, max-age=3600", "X-Content-Type-Options": "nosniff" },
  });
}
